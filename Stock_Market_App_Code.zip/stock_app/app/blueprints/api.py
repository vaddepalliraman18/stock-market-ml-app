"""
Flask API Blueprint  —  /api/v1/*

Endpoints:
  GET  /api/v1/tickers               list supported tickers
  POST /api/v1/stock-data            OHLCV + indicator series (JSON)
  POST /api/v1/predict               run model prediction with CI
  GET  /api/v1/model-comparison/<t>  all 4 model metrics for ticker
  GET  /api/v1/audit-log             prediction history for session
"""

import logging, time, json
import numpy as np
import pandas as pd
from flask import Blueprint, request, jsonify, session, current_app
from pipeline.data_pipeline import StockDataPipeline, TICKERS
from pipeline.features import FeatureEngineer
from pipeline.preprocessor import StockPreprocessor
from models.model_factory import ModelFactory
from models.evaluator import DirectionalEvaluator

api_bp = Blueprint("api", __name__, url_prefix="/api/v1")
logger = logging.getLogger(__name__)

_factory_cache: dict[str, ModelFactory] = {}
dir_eval = DirectionalEvaluator()

# ─────────────────────────────────────────────────────────────────────

def get_factory(ticker: str) -> ModelFactory:
    if ticker not in _factory_cache:
        f = ModelFactory(ticker)
        f.load_all()
        _factory_cache[ticker] = f
    return _factory_cache[ticker]


def get_pipeline() -> StockDataPipeline:
    db_path = current_app.config.get("DB_PATH", "data/stocks.db")
    return StockDataPipeline(db_path)

# ─────────────────────────────────────────────────────────────────────
# GET /api/v1/tickers
# ─────────────────────────────────────────────────────────────────────

@api_bp.get("/tickers")
def list_tickers():
    return jsonify({"tickers": TICKERS})

# ─────────────────────────────────────────────────────────────────────
# POST /api/v1/stock-data
# Body: { "ticker": "TCS.NS", "start": "2023-01-01", "end": "2024-01-01",
#         "indicators": ["rsi_14","macd","bb_upper","bb_lower","sma_20"] }
# ─────────────────────────────────────────────────────────────────────

@api_bp.post("/stock-data")
def stock_data():
    body   = request.get_json(force=True)
    ticker = body.get("ticker", "")
    start  = body.get("start")
    end    = body.get("end")
    inds   = body.get("indicators", [])

    if ticker not in TICKERS:
        return jsonify({"error": f"Unknown ticker: {ticker}"}), 400

    try:
        pipeline = get_pipeline()
        df = pipeline.get_ohlcv(ticker, start, end)
        if df.empty:
            # Fallback: live fetch
            import yfinance as yf
            df = yf.download(ticker, start=start, end=end,
                             auto_adjust=True, progress=False)

        # Rebuild indicators on-the-fly for the requested window
        fe = FeatureEngineer()
        df_feat = fe.transform(df)

        ohlcv_records = []
        for ts, row in df.iterrows():
            ohlcv_records.append({
                "date":   ts.strftime("%Y-%m-%d"),
                "open":   round(float(row["Open"]),  2),
                "high":   round(float(row["High"]),  2),
                "low":    round(float(row["Low"]),   2),
                "close":  round(float(row["Close"]), 2),
                "volume": int(row["Volume"]),
            })

        indicator_series = {}
        for ind in inds:
            if ind in df_feat.columns:
                s = df_feat[ind].dropna()
                indicator_series[ind] = [
                    {"date": ts.strftime("%Y-%m-%d"),
                     "value": round(float(v), 4)}
                    for ts, v in s.items()
                ]

        # Latest indicator values + interpretations
        last = df_feat.iloc[-1]
        insights = _indicator_insights(last)

        return jsonify({
            "ticker":     ticker,
            "ohlcv":      ohlcv_records,
            "indicators": indicator_series,
            "insights":   insights,
        })
    except Exception as exc:
        logger.exception(exc)
        return jsonify({"error": str(exc)}), 500

# ─────────────────────────────────────────────────────────────────────
# POST /api/v1/predict
# Body: { "ticker": "AAPL", "model": "lstm", "horizon": 1 }
# ─────────────────────────────────────────────────────────────────────

@api_bp.post("/predict")
def predict():
    body    = request.get_json(force=True)
    ticker  = body.get("ticker", "")
    model_name = body.get("model", "lstm").lower()
    horizon = int(body.get("horizon", 1))

    if ticker not in TICKERS:
        return jsonify({"error": f"Unknown ticker: {ticker}"}), 400
    if model_name not in ("ridge", "dtree", "rf", "lstm"):
        return jsonify({"error": "model must be ridge/dtree/rf/lstm"}), 400

    try:
        t0 = time.time()
        import yfinance as yf
        raw = yf.download(ticker, period="200d",
                          auto_adjust=True, progress=False)
        fe  = FeatureEngineer()
        df  = fe.transform(raw)

        feature_cols = [c for c in df.columns
                        if c not in {"Open","High","Low","Close","Volume"}]
        X = df[feature_cols].values
        y = df["Close"].values

        factory = get_factory(ticker)
        model   = factory.get_model(model_name)
        if model is None or model.model is None:
            return jsonify({"error": f"Model {model_name} not trained yet "
                                     f"for {ticker}"}), 404

        if model_name == "lstm":
            mean_pred, lower, upper = model.predict_with_ci(X)
        else:
            mean_pred = model.predict(X)
            std = np.std(mean_pred) * 0.05
            lower = mean_pred - 1.645 * std
            upper = mean_pred + 1.645 * std

        # Only return the last `horizon` steps
        predicted_prices = mean_pred[-horizon:].tolist()
        ci_lower         = lower[-horizon:].tolist()
        ci_upper         = upper[-horizon:].tolist()
        last_close       = float(y[-1])
        pct_change       = round(
            (predicted_prices[0] - last_close) / last_close * 100, 2
        )

        # Recent actual vs predicted (last 5 rows)
        recent_actuals = y[-5:].tolist()
        recent_preds   = mean_pred[-5:].tolist()
        recent_table   = [
            {"actual": round(a, 2), "predicted": round(p, 2)}
            for a, p in zip(recent_actuals, recent_preds)
        ]

        metrics = factory.results.get(model_name, {})
        elapsed = round(time.time() - t0, 2)

        # Save to session audit log
        if "audit_log" not in session:
            session["audit_log"] = []
        session["audit_log"].append({
            "ticker":    ticker,
            "model":     model_name,
            "predicted": round(predicted_prices[0], 2),
            "pct":       pct_change,
            "elapsed_s": elapsed,
        })
        session.modified = True

        return jsonify({
            "ticker":           ticker,
            "model":            model_name,
            "horizon":          horizon,
            "predicted_prices": [round(p, 2) for p in predicted_prices],
            "confidence_lower": [round(v, 2) for v in ci_lower],
            "confidence_upper": [round(v, 2) for v in ci_upper],
            "last_close":       round(last_close, 2),
            "pct_change":       pct_change,
            "recent_table":     recent_table,
            "metrics":          metrics,
            "elapsed_s":        elapsed,
        })
    except Exception as exc:
        logger.exception(exc)
        return jsonify({"error": str(exc)}), 500

# ─────────────────────────────────────────────────────────────────────
# GET /api/v1/model-comparison/<ticker>
# ─────────────────────────────────────────────────────────────────────

@api_bp.get("/model-comparison/<ticker>")
def model_comparison(ticker):
    if ticker not in TICKERS:
        return jsonify({"error": f"Unknown ticker: {ticker}"}), 400
    factory = get_factory(ticker)
    return jsonify({"ticker": ticker, "results": factory.results})

# ─────────────────────────────────────────────────────────────────────
# GET /api/v1/audit-log
# ─────────────────────────────────────────────────────────────────────

@api_bp.get("/audit-log")
def audit_log():
    return jsonify({"log": session.get("audit_log", [])})

# ─────────────────────────────────────────────────────────────────────
# Helper — generate Indicator Insights text
# ─────────────────────────────────────────────────────────────────────

def _indicator_insights(row: pd.Series) -> dict:
    insights = {}
    if "rsi_14" in row and not pd.isna(row["rsi_14"]):
        v = row["rsi_14"]
        if v > 70:
            msg = f"RSI = {v:.1f} — overbought territory (>70). Often signals near-term pullback."
        elif v < 30:
            msg = f"RSI = {v:.1f} — oversold territory (<30). May signal upcoming rebound."
        else:
            msg = f"RSI = {v:.1f} — neutral range (30–70). No immediate overbought/oversold signal."
        insights["rsi_14"] = msg

    if "macd" in row and not pd.isna(row["macd"]):
        v = row["macd"]
        s = row.get("macd_signal", 0)
        if v > s:
            insights["macd"] = f"MACD = {v:.3f} > Signal ({s:.3f}) — bullish crossover signal."
        else:
            insights["macd"] = f"MACD = {v:.3f} < Signal ({s:.3f}) — bearish crossover signal."

    if "bb_position" in row and not pd.isna(row["bb_position"]):
        v = row["bb_position"]
        if v > 0.9:
            insights["bb"] = f"Price near upper Bollinger Band ({v:.0%}). Watch for mean reversion."
        elif v < 0.1:
            insights["bb"] = f"Price near lower Bollinger Band ({v:.0%}). Potential support level."
        else:
            insights["bb"] = f"Price is {v:.0%} within Bollinger Bands — mid-range."

    return insights
