"""Flask main blueprint — HTML page routes."""

from flask import Blueprint, render_template, session
from pipeline.data_pipeline import TICKERS

main_bp = Blueprint("main", __name__)


@main_bp.get("/")
def index():
    return render_template("index.html", tickers=TICKERS)


@main_bp.get("/compare")
def compare():
    return render_template("compare.html", tickers=TICKERS)


@main_bp.get("/watchlist")
def watchlist():
    items = session.get("watchlist", [])
    return render_template("watchlist.html", tickers=TICKERS, watchlist=items)


@main_bp.post("/watchlist/add/<ticker>")
def watchlist_add(ticker):
    from flask import redirect, url_for
    from pipeline.data_pipeline import TICKERS as T
    if ticker in T:
        wl = session.get("watchlist", [])
        if ticker not in wl and len(wl) < 10:
            wl.append(ticker)
            session["watchlist"] = wl
    return redirect(url_for("main.watchlist"))


@main_bp.post("/watchlist/remove/<ticker>")
def watchlist_remove(ticker):
    from flask import redirect, url_for
    wl = session.get("watchlist", [])
    session["watchlist"] = [t for t in wl if t != ticker]
    return redirect(url_for("main.watchlist"))


@main_bp.get("/audit")
def audit():
    return render_template("audit.html", log=session.get("audit_log", []))
