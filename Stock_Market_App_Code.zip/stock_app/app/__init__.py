"""Flask application factory."""

import os, logging
from flask import Flask


def create_app(db_path: str = "data/stocks.db") -> Flask:
    app = Flask(__name__, template_folder="templates",
                static_folder="static")

    app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    app.config["DB_PATH"]       = db_path
    app.config["SESSION_TYPE"]  = "filesystem"
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    from app.blueprints.main import main_bp
    from app.blueprints.api  import api_bp
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp)

    return app
