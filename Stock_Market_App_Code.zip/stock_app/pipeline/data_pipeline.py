"""
StockDataPipeline — ETL: Extract (yfinance) → Transform → Load (SQLite)
"""

import os, logging
import pandas as pd
import yfinance as yf
from sqlalchemy import create_engine, text
from pipeline.preprocessor import StockPreprocessor
from pipeline.features import FeatureEngineer

logger = logging.getLogger(__name__)

TICKERS = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "AAPL", "MSFT", "AMZN", "GOOGL", "TSLA"
]
DB_PATH = "data/stocks.db"


class StockDataPipeline:
    """Full ETL pipeline for all TICKERS."""

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.engine = create_engine(f"sqlite:///{db_path}")
        self.fe = FeatureEngineer()

    # ─────────────────────────────────────────────────────────────────
    # PUBLIC
    # ─────────────────────────────────────────────────────────────────

    def run(self, start: str = "2014-01-01", end: str = "2023-12-31"):
        """Run full ETL for all tickers."""
        logger.info(f"Pipeline start: {start} → {end}")
        raw = self.extract(TICKERS, start, end)
        for ticker in TICKERS:
            try:
                df = raw[ticker] if isinstance(raw.columns, pd.MultiIndex) else raw
                df = self.transform(df, ticker)
                self.load(df, ticker)
            except Exception as exc:
                logger.error(f"[{ticker}] Pipeline error: {exc}")
        logger.info("Pipeline complete.")

    def extract(self, tickers: list, start: str, end: str) -> pd.DataFrame:
        """Download OHLCV data from Yahoo Finance (parallel threads)."""
        logger.info(f"Downloading {len(tickers)} tickers …")
        data = yf.download(
            tickers,
            start=start,
            end=end,
            auto_adjust=True,
            group_by="ticker",
            threads=True,
            progress=False,
        )
        return data

    def transform(self, df: pd.DataFrame, ticker: str) -> pd.DataFrame:
        """Preprocess + feature engineer a single ticker DataFrame."""
        # Ensure index is DatetimeIndex
        if not isinstance(df.index, pd.DatetimeIndex):
            df.index = pd.to_datetime(df.index)
        df = df.sort_index()

        preprocessor = StockPreprocessor(ticker)
        df = preprocessor.fit_transform(df)
        df = self.fe.transform(df)
        df.insert(0, "ticker", ticker)
        return df

    def load(self, df: pd.DataFrame, ticker: str):
        """Bulk insert cleaned DataFrame into SQLite."""
        with self.engine.begin() as conn:
            df.to_sql("price_features", conn, if_exists="append",
                      index=True, index_label="date")
        logger.info(f"[{ticker}] Loaded {len(df)} rows into price_features")

    # ─────────────────────────────────────────────────────────────────
    # READ helpers (used by Flask app)
    # ─────────────────────────────────────────────────────────────────

    def get_ohlcv(self, ticker: str, start: str = None,
                  end: str = None) -> pd.DataFrame:
        q = "SELECT date, Open, High, Low, Close, Volume FROM price_features WHERE ticker=:t"
        params = {"t": ticker}
        if start:
            q += " AND date >= :s"
            params["s"] = start
        if end:
            q += " AND date <= :e"
            params["e"] = end
        q += " ORDER BY date"
        with self.engine.connect() as conn:
            df = pd.read_sql(text(q), conn, params=params,
                             parse_dates=["date"], index_col="date")
        return df

    def get_features(self, ticker: str, n_rows: int = None) -> pd.DataFrame:
        q = "SELECT * FROM price_features WHERE ticker=:t ORDER BY date"
        if n_rows:
            q += f" LIMIT {n_rows}"
        with self.engine.connect() as conn:
            df = pd.read_sql(text(q), conn, params={"t": ticker},
                             parse_dates=["date"], index_col="date")
        return df.drop(columns=["ticker"], errors="ignore")
