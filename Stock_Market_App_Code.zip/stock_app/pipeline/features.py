"""
FeatureEngineer — 48 features across 7 categories:
  Moving Averages (7) | Momentum Oscillators (6) | Volatility (5)
  Volume (4) | Lag & Return (8) | Calendar (4) | Price Ratios (14)
"""

import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class FeatureEngineer:
    """Add all 48 engineered features to a raw OHLCV DataFrame."""

    FEATURE_COLS: list[str] = []   # populated after first call

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Return df with all 48 feature columns appended."""
        df = df.copy()
        df = self._moving_averages(df)
        df = self._momentum_oscillators(df)
        df = self._volatility_indicators(df)
        df = self._volume_indicators(df)
        df = self._lag_return_features(df)
        df = self._calendar_features(df)
        df = self._price_derived_ratios(df)
        df = df.dropna()
        FeatureEngineer.FEATURE_COLS = [
            c for c in df.columns
            if c not in {"Open", "High", "Low", "Close", "Volume"}
        ]
        logger.info(f"Feature engineering: {len(FeatureEngineer.FEATURE_COLS)} "
                    f"features, {len(df)} rows after dropna")
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 1 — Moving Averages (7)
    # ─────────────────────────────────────────────────────────────────

    def _moving_averages(self, df: pd.DataFrame) -> pd.DataFrame:
        close = df["Close"]
        for w in [10, 20, 50, 200]:
            df[f"sma_{w}"] = close.rolling(window=w).mean()
        for span in [12, 26, 50]:
            df[f"ema_{span}"] = close.ewm(span=span, adjust=False).mean()
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 2 — Momentum Oscillators (6)
    # ─────────────────────────────────────────────────────────────────

    def _momentum_oscillators(self, df: pd.DataFrame) -> pd.DataFrame:
        close = df["Close"]

        # RSI-14
        delta = close.diff()
        gain = delta.clip(lower=0).rolling(14).mean()
        loss = (-delta.clip(upper=0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        df["rsi_14"] = 100 - (100 / (1 + rs))

        # MACD
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        df["macd"] = ema12 - ema26
        df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
        df["macd_hist"] = df["macd"] - df["macd_signal"]

        # Stochastic %K / %D
        low14  = df["Low"].rolling(14).min()
        high14 = df["High"].rolling(14).max()
        df["stoch_k"] = 100 * (close - low14) / (high14 - low14 + 1e-9)
        df["stoch_d"] = df["stoch_k"].rolling(3).mean()
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 3 — Volatility Indicators (5)
    # ─────────────────────────────────────────────────────────────────

    def _volatility_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        close = df["Close"]
        sma20 = close.rolling(20).mean()
        std20 = close.rolling(20).std()
        df["bb_upper"]  = sma20 + 2 * std20
        df["bb_mid"]    = sma20
        df["bb_lower"]  = sma20 - 2 * std20

        # ATR-14
        hl  = df["High"] - df["Low"]
        hpc = (df["High"] - close.shift(1)).abs()
        lpc = (df["Low"]  - close.shift(1)).abs()
        tr  = pd.concat([hl, hpc, lpc], axis=1).max(axis=1)
        df["atr_14"] = tr.rolling(14).mean()

        # Historical volatility (20-day rolling std of log returns × √252)
        log_ret = np.log(close / close.shift(1))
        df["hv_20"] = log_ret.rolling(20).std() * np.sqrt(252)
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 4 — Volume Indicators (4)
    # ─────────────────────────────────────────────────────────────────

    def _volume_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        close  = df["Close"]
        volume = df["Volume"]

        # OBV
        direction = np.sign(close.diff()).fillna(0)
        df["obv"] = (direction * volume).cumsum()

        # VWAP (rolling approximation — cumulative within dataset)
        df["vwap"] = (close * volume).cumsum() / volume.cumsum()

        # Volume SMA-20 and ratio
        df["vol_sma_20"] = volume.rolling(20).mean()
        df["vol_ratio"]  = volume / df["vol_sma_20"].replace(0, np.nan)
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 5 — Lag & Return Features (8)
    # ─────────────────────────────────────────────────────────────────

    def _lag_return_features(self, df: pd.DataFrame) -> pd.DataFrame:
        close = df["Close"]
        for lag in [1, 5, 10, 20]:
            df[f"lag_close_{lag}"] = close.shift(lag)

        df["ret_daily"]   = close.pct_change(1)
        df["ret_weekly"]  = close.pct_change(5)
        df["ret_monthly"] = close.pct_change(20)
        df["rolling_std_20"] = close.rolling(20).std()
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 6 — Calendar Features (4)
    # ─────────────────────────────────────────────────────────────────

    def _calendar_features(self, df: pd.DataFrame) -> pd.DataFrame:
        idx = pd.DatetimeIndex(df.index)
        df["dow"]          = idx.dayofweek + 1          # 1=Mon…5=Fri
        df["month"]        = idx.month
        df["quarter"]      = idx.quarter
        df["is_month_end"] = idx.is_month_end.astype(int)
        return df

    # ─────────────────────────────────────────────────────────────────
    # Category 7 — Price-Derived Ratios (14)
    # ─────────────────────────────────────────────────────────────────

    def _price_derived_ratios(self, df: pd.DataFrame) -> pd.DataFrame:
        close = df["Close"]

        df["hl_range"]         = df["High"] - df["Low"]
        df["close_sma20_ratio"]= close / df["sma_20"].replace(0, np.nan)
        df["close_sma50_ratio"]= close / df["sma_50"].replace(0, np.nan)
        df["close_ema12_ratio"]= close / df["ema_12"].replace(0, np.nan)

        # Close position within Bollinger Band
        band_width = (df["bb_upper"] - df["bb_lower"]).replace(0, np.nan)
        df["bb_position"]      = (close - df["bb_lower"]) / band_width

        # RSI divergence (price up but RSI down compared to 5 days ago)
        df["rsi_divergence"]   = df["rsi_14"] - df["rsi_14"].shift(5)

        df["macd_momentum"]    = df["macd"] - df["macd"].shift(3)
        df["stoch_momentum"]   = df["stoch_k"] - df["stoch_k"].shift(3)

        df["high_sma20_ratio"] = df["High"] / df["sma_20"].replace(0, np.nan)
        df["low_sma20_ratio"]  = df["Low"]  / df["sma_20"].replace(0, np.nan)
        df["oc_range"]         = (close - df["Open"]).abs() / df["Open"].replace(0, np.nan)
        df["ema12_26_spread"]  = df["ema_12"] - df["ema_26"]
        df["sma10_20_cross"]   = df["sma_10"] - df["sma_20"]
        df["atr_pct"]          = df["atr_14"] / close.replace(0, np.nan)
        return df
