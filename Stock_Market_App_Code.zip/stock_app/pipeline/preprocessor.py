"""
StockPreprocessor — full preprocessing pipeline
Steps: missing values → split adjustment → outlier detection →
       feature scaling → stationarity check
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from scipy.stats import shapiro
import joblib, os, json, logging

logger = logging.getLogger(__name__)

SEED = 42
np.random.seed(SEED)


class StockPreprocessor:
    """Reproducible preprocessing pipeline for one stock ticker."""

    def __init__(self, ticker: str, scaler_dir: str = "models/scalers"):
        self.ticker = ticker
        self.scaler_dir = scaler_dir
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.audit = {}
        os.makedirs(scaler_dir, exist_ok=True)

    # ─────────────────────────────────────────────────────────────────
    # PUBLIC
    # ─────────────────────────────────────────────────────────────────

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply all preprocessing steps on training data and save scaler."""
        df = df.copy()
        df = self._handle_missing(df)
        df = self._verify_adjusted_close(df)
        df = self._detect_outliers(df)
        df = self._check_stationarity(df)
        df = self._scale(df, fit=True)
        self._save_scaler()
        self._log_audit()
        return df

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply saved scaler to test / live data (no refitting)."""
        self._load_scaler()
        df = df.copy()
        df = self._handle_missing(df)
        df = self._scale(df, fit=False)
        return df

    # ─────────────────────────────────────────────────────────────────
    # STEP 1 — Missing values
    # ─────────────────────────────────────────────────────────────────

    def _handle_missing(self, df: pd.DataFrame) -> pd.DataFrame:
        before = len(df)
        # forward fill volume gaps <= 3 days
        df["Volume"] = df["Volume"].fillna(method="ffill", limit=3)
        # drop rows with remaining NaN (gap > 3 days)
        dropped = df[df.isnull().any(axis=1)]
        df = df.dropna()
        self.audit["missing_dropped"] = len(dropped)
        self.audit["records_after_missing"] = len(df)
        logger.info(f"[{self.ticker}] Missing: dropped {len(dropped)} rows "
                    f"({before} → {len(df)})")
        return df

    # ─────────────────────────────────────────────────────────────────
    # STEP 2 — Adjusted Close verification
    # ─────────────────────────────────────────────────────────────────

    def _verify_adjusted_close(self, df: pd.DataFrame) -> pd.DataFrame:
        # Check for potential unadjusted splits: look for single-day
        # price jumps > 40% that don't match a real market move pattern
        pct = df["Close"].pct_change().abs()
        suspicious = pct[pct > 0.40]
        self.audit["suspicious_split_dates"] = suspicious.index.strftime(
            "%Y-%m-%d").tolist()
        if len(suspicious):
            logger.warning(f"[{self.ticker}] {len(suspicious)} dates with "
                           f">40% single-day move — verify split adjustment.")
        return df

    # ─────────────────────────────────────────────────────────────────
    # STEP 3 — Outlier detection (IQR on log returns)
    # ─────────────────────────────────────────────────────────────────

    def _detect_outliers(self, df: pd.DataFrame) -> pd.DataFrame:
        log_ret = np.log(df["Close"] / df["Close"].shift(1)).dropna()
        mu, sigma = log_ret.mean(), log_ret.std()
        flagged = log_ret[log_ret.abs() > 4 * sigma]
        self.audit["outliers_flagged"] = len(flagged)
        self.audit["outlier_dates"] = flagged.index.strftime("%Y-%m-%d").tolist()
        # Retain outliers — they represent real market events (COVID crash etc.)
        logger.info(f"[{self.ticker}] Outliers flagged (retained): "
                    f"{len(flagged)} dates")
        return df

    # ─────────────────────────────────────────────────────────────────
    # STEP 4 — Stationarity (ADF test via statsmodels if available)
    # ─────────────────────────────────────────────────────────────────

    def _check_stationarity(self, df: pd.DataFrame) -> pd.DataFrame:
        try:
            from statsmodels.tsa.stattools import adfuller
            result = adfuller(df["Close"].dropna())
            self.audit["adf_stat"] = float(result[0])
            self.audit["adf_pvalue"] = float(result[1])
            self.audit["is_stationary"] = result[1] < 0.05
            logger.info(f"[{self.ticker}] ADF stat={result[0]:.3f} "
                        f"p={result[1]:.4f} stationary={result[1] < 0.05}")
        except ImportError:
            self.audit["adf_stat"] = "statsmodels not installed"
        return df

    # ─────────────────────────────────────────────────────────────────
    # STEP 5 — MinMax scaling
    # ─────────────────────────────────────────────────────────────────

    def _scale(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if fit:
            df[numeric_cols] = self.scaler.fit_transform(df[numeric_cols])
        else:
            df[numeric_cols] = self.scaler.transform(df[numeric_cols])
        return df

    # ─────────────────────────────────────────────────────────────────
    # Persistence
    # ─────────────────────────────────────────────────────────────────

    def _save_scaler(self):
        path = os.path.join(self.scaler_dir, f"{self.ticker}_scaler.pkl")
        joblib.dump(self.scaler, path)
        logger.info(f"[{self.ticker}] Scaler saved → {path}")

    def _load_scaler(self):
        path = os.path.join(self.scaler_dir, f"{self.ticker}_scaler.pkl")
        if not os.path.exists(path):
            raise FileNotFoundError(f"Scaler not found: {path}")
        self.scaler = joblib.load(path)

    def _log_audit(self):
        path = os.path.join(self.scaler_dir,
                            f"{self.ticker}_preprocess_audit.json")
        with open(path, "w") as f:
            json.dump(self.audit, f, indent=2, default=str)
        logger.info(f"[{self.ticker}] Audit log saved → {path}")
