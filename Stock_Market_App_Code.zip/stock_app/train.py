"""
train.py — Train all 4 models for all 10 tickers.
Usage:
    python train.py                     # train all tickers
    python train.py --ticker TCS.NS     # train one ticker
    python train.py --ticker TCS.NS --model lstm  # one model only
"""

import argparse, logging, os, json
import numpy as np
import pandas as pd
import yfinance as yf

from pipeline.features import FeatureEngineer
from pipeline.preprocessor import StockPreprocessor
from models.model_factory import ModelFactory
from models.evaluator import StatisticalValidator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

TICKERS = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "AAPL", "MSFT", "AMZN", "GOOGL", "TSLA",
]
TRAIN_START = "2014-01-01"
TRAIN_END   = "2023-12-31"
RESULTS_FILE = "models/all_results.json"
os.makedirs("models/saved",   exist_ok=True)
os.makedirs("models/scalers", exist_ok=True)


def download_and_prepare(ticker: str):
    """Download → preprocess → feature engineer for one ticker."""
    logger.info(f"[{ticker}] Downloading data {TRAIN_START} → {TRAIN_END} …")
    raw = yf.download(
        ticker, start=TRAIN_START, end=TRAIN_END,
        auto_adjust=True, progress=False,
    )
    if raw.empty:
        raise ValueError(f"No data returned for {ticker}")

    # Flatten MultiIndex columns if present
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = raw.columns.get_level_values(0)

    preprocessor = StockPreprocessor(ticker)
    df = preprocessor.fit_transform(raw)

    fe = FeatureEngineer()
    df = fe.transform(df)

    feature_cols = [
        c for c in df.columns
        if c not in {"Open", "High", "Low", "Close", "Volume", "ticker"}
    ]
    X = df[feature_cols].values.astype(np.float32)
    y = df["Close"].values.astype(np.float32)

    logger.info(f"[{ticker}] Prepared: X={X.shape}, y={y.shape}")
    return X, y


def train_ticker(ticker: str, models_filter: list = None) -> dict:
    X, y = download_and_prepare(ticker)
    factory = ModelFactory(ticker)

    if models_filter:
        factory.models = {k: v for k, v in factory.models.items()
                          if k in models_filter}

    results = factory.run(X, y)
    return results


def run_cross_ticker_stats(all_results: dict):
    """
    After training all tickers, run cross-ticker statistical tests
    (Wilcoxon pairwise + Friedman) on the MAE distributions.
    """
    model_names = ["ridge", "dtree", "rf", "lstm"]
    mae_by_model = {m: [] for m in model_names}

    for ticker, res in all_results.items():
        for m in model_names:
            if m in res and "mae" in res[m]:
                mae_by_model[m].append(res[m]["mae"])

    logger.info("=== Cross-ticker Statistical Tests ===")

    # Pairwise: LSTM vs others
    for other in ["rf", "dtree", "ridge"]:
        if len(mae_by_model["lstm"]) >= 6 and len(mae_by_model[other]) >= 6:
            result = StatisticalValidator.wilcoxon_pairwise(
                mae_by_model["lstm"], mae_by_model[other],
                "LSTM", other.upper()
            )
            logger.info(f"Wilcoxon LSTM vs {other.upper()}: "
                        f"W={result['W']:.1f} p={result['p_value']:.4f} "
                        f"reject={result['reject_h0']}")

    # Friedman across all 4 models
    lists = [mae_by_model[m] for m in model_names
             if len(mae_by_model[m]) >= 6]
    if len(lists) == 4:
        fr = StatisticalValidator.friedman_test(*lists)
        logger.info(f"Friedman χ²={fr['chi2']} p={fr['p_value']} "
                    f"reject={fr['reject_h0']}")


def main():
    parser = argparse.ArgumentParser(description="Train stock prediction models")
    parser.add_argument("--ticker", default=None,
                        help="Single ticker to train (default: all)")
    parser.add_argument("--model", default=None,
                        choices=["ridge", "dtree", "rf", "lstm"],
                        help="Single model to train (default: all)")
    args = parser.parse_args()

    tickers_to_train = [args.ticker] if args.ticker else TICKERS
    models_filter    = [args.model]  if args.model  else None

    all_results = {}
    for ticker in tickers_to_train:
        try:
            results = train_ticker(ticker, models_filter)
            all_results[ticker] = results
            logger.info(f"[{ticker}] Training complete: {results}")
        except Exception as exc:
            logger.error(f"[{ticker}] FAILED: {exc}")

    # Save consolidated results
    with open(RESULTS_FILE, "w") as f:
        json.dump(all_results, f, indent=2, default=str)
    logger.info(f"All results saved → {RESULTS_FILE}")

    # Cross-ticker stats (only meaningful when all tickers trained)
    if not args.ticker and not args.model:
        run_cross_ticker_stats(all_results)


if __name__ == "__main__":
    main()
