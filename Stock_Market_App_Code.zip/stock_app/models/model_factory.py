"""
ModelFactory — train, evaluate, and persist all models for one ticker.
"""

import logging
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
from models.base_model import RidgePredictor, DecisionTreePredictor, RandomForestPredictor
from models.lstm_model import LSTMPredictor
from models.evaluator import DirectionalEvaluator, StatisticalValidator

logger = logging.getLogger(__name__)

LOOKBACK   = 60
TEST_RATIO = 0.2
SEED       = 42


class ModelFactory:
    """Train + evaluate all 4 models for a single stock ticker."""

    def __init__(self, ticker: str):
        self.ticker = ticker
        self.dir_eval = DirectionalEvaluator()

        self.models = {
            "ridge":  RidgePredictor(ticker),
            "dtree":  DecisionTreePredictor(ticker),
            "rf":     RandomForestPredictor(ticker),
            "lstm":   LSTMPredictor(ticker),
        }
        self.results: dict = {}

    # ─────────────────────────────────────────────────────────────────

    def run(self, X: np.ndarray, y: np.ndarray) -> dict:
        """
        Temporal train/test split → fit all models → evaluate.
        Returns dict of results per model.
        """
        split = int(len(X) * (1 - TEST_RATIO))
        X_tr, X_te = X[:split], X[split:]
        y_tr, y_te = y[:split], y[split:]

        logger.info(f"[{self.ticker}] Train={len(X_tr)}, Test={len(X_te)}")

        mae_per_model = {}
        for name, model in self.models.items():
            logger.info(f"[{self.ticker}] Fitting {name} …")
            try:
                model.fit(X_tr, y_tr)
                # LSTM needs sequences — adjust test accordingly
                if name == "lstm":
                    preds = model.predict(X_te)
                    y_true = y_te[LOOKBACK:]          # align targets
                else:
                    preds  = model.predict(X_te)
                    y_true = y_te

                reg_metrics = model.evaluate(y_true, preds)
                dir_metrics = self.dir_eval.evaluate(y_true, preds)

                self.results[name] = {**reg_metrics, **dir_metrics}
                mae_per_model[name] = reg_metrics["mae"]
                model.save()
                logger.info(f"[{self.ticker}] {name}: {reg_metrics}")
            except Exception as exc:
                logger.error(f"[{self.ticker}] {name} FAILED: {exc}")

        # Statistical tests (need at least LSTM + RF)
        if "lstm" in mae_per_model and "rf" in mae_per_model:
            # We only have one value per model here (1 stock), so
            # statistical tests are meaningful at cross-stock level.
            # Log the values for later aggregation.
            logger.info(f"[{self.ticker}] MAE summary: {mae_per_model}")

        return self.results

    # ─────────────────────────────────────────────────────────────────

    def load_all(self):
        """Load pre-trained models from disk."""
        for name, model in self.models.items():
            try:
                model.load()
                logger.info(f"[{self.ticker}] {name} loaded")
            except FileNotFoundError as e:
                logger.warning(str(e))

    def get_model(self, name: str):
        return self.models.get(name)
