"""
LSTMPredictor — 2-layer LSTM with Monte Carlo Dropout confidence intervals.
Architecture: Input(60×48) → LSTM(128) → DO(0.2) → LSTM(64) → DO(0.2)
              → Dense(32,ReLU) → Dense(1)
"""

import os, logging
import numpy as np
from models.base_model import BaseStockPredictor

logger = logging.getLogger(__name__)
SEED = 42
MC_PASSES = 10


class SequenceGenerator:
    """Sliding-window sequence builder for LSTM input."""

    def __init__(self, lookback: int = 60):
        self.lookback = lookback

    def build(self, X: np.ndarray,
              y: np.ndarray = None) -> tuple:
        Xs, ys = [], []
        for i in range(self.lookback, len(X)):
            Xs.append(X[i - self.lookback: i])
            if y is not None:
                ys.append(y[i])
        Xs = np.array(Xs)
        ys = np.array(ys) if y is not None else None
        return (Xs, ys) if y is not None else Xs


class LSTMPredictor(BaseStockPredictor):

    def __init__(self, ticker: str, lookback: int = 60, n_features: int = 48):
        super().__init__(ticker)
        self.lookback   = lookback
        self.n_features = n_features
        self.seq_gen    = SequenceGenerator(lookback)
        self.history    = None

    # ─────────────────────────────────────────────────────────────────

    def fit(self, X_train: np.ndarray, y_train: np.ndarray):
        import tensorflow as tf
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import LSTM, Dense, Dropout
        from tensorflow.keras.optimizers import Adam
        from tensorflow.keras.callbacks import (
            EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
        )

        tf.random.set_seed(SEED)
        np.random.seed(SEED)

        X_seq, y_seq = self.seq_gen.build(X_train, y_train)
        ckpt_path = f"models/saved/{self.ticker}_lstm_best.h5"

        model = Sequential([
            LSTM(128, input_shape=(self.lookback, X_train.shape[1]),
                 return_sequences=True),
            Dropout(0.2),
            LSTM(64),
            Dropout(0.2),
            Dense(32, activation="relu"),
            Dense(1),
        ])
        model.compile(optimizer=Adam(learning_rate=0.001,
                                     beta_1=0.9, beta_2=0.999),
                      loss="mse")

        callbacks = [
            EarlyStopping(patience=10, monitor="val_loss",
                          restore_best_weights=True),
            ReduceLROnPlateau(factor=0.5, patience=5, monitor="val_loss"),
            ModelCheckpoint(ckpt_path, save_best_only=True,
                            monitor="val_loss"),
        ]

        self.history = model.fit(
            X_seq, y_seq,
            epochs=100,
            batch_size=32,
            validation_split=0.1,
            callbacks=callbacks,
            verbose=1,
        )
        self.model = model
        logger.info(f"[{self.ticker}] LSTM trained "
                    f"({len(self.history.epoch)} epochs)")
        return self

    # ─────────────────────────────────────────────────────────────────

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Deterministic single-pass prediction."""
        X_seq = self.seq_gen.build(X)
        return self.model.predict(X_seq, verbose=0).flatten()

    def predict_with_ci(self, X: np.ndarray,
                        passes: int = MC_PASSES) -> tuple:
        """
        Monte Carlo Dropout — run `passes` forward passes with dropout
        active at inference to generate prediction distribution.
        Returns (mean_pred, lower_90, upper_90).
        """
        import tensorflow as tf

        X_seq = self.seq_gen.build(X)
        preds = np.stack([
            self.model(X_seq, training=True).numpy().flatten()
            for _ in range(passes)
        ])
        mean  = preds.mean(axis=0)
        lower = np.percentile(preds,  5, axis=0)
        upper = np.percentile(preds, 95, axis=0)
        return mean, lower, upper

    # ─────────────────────────────────────────────────────────────────

    def save(self):
        path = f"models/saved/{self.ticker}_LSTMPredictor.h5"
        self.model.save(path)
        logger.info(f"[{self.ticker}] LSTM saved → {path}")

    def load(self):
        from tensorflow.keras.models import load_model
        path = f"models/saved/{self.ticker}_LSTMPredictor.h5"
        if not os.path.exists(path):
            raise FileNotFoundError(f"LSTM model not found: {path}")
        self.model = load_model(path)
        logger.info(f"[{self.ticker}] LSTM loaded ← {path}")
