"""
BaseStockPredictor + concrete classical models:
  RidgePredictor | DecisionTreePredictor | RandomForestPredictor
"""

import os, joblib, logging
import numpy as np
import pandas as pd
from abc import ABC, abstractmethod
from sklearn.linear_model import RidgeCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV, RandomizedSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

logger = logging.getLogger(__name__)
MODEL_DIR = "models/saved"
SEED = 42


class BaseStockPredictor(ABC):
    """Interface every model must implement."""

    def __init__(self, ticker: str):
        self.ticker = ticker
        self.model = None
        os.makedirs(MODEL_DIR, exist_ok=True)

    @abstractmethod
    def fit(self, X_train: np.ndarray, y_train: np.ndarray): ...

    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray: ...

    def evaluate(self, y_true: np.ndarray,
                 y_pred: np.ndarray) -> dict:
        mae  = mean_absolute_error(y_true, y_pred)
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        r2   = r2_score(y_true, y_pred)
        return {"mae": round(mae, 4), "rmse": round(rmse, 4), "r2": round(r2, 4)}

    def save(self):
        path = os.path.join(MODEL_DIR,
                            f"{self.ticker}_{self.__class__.__name__}.pkl")
        joblib.dump(self.model, path)
        logger.info(f"Saved model → {path}")

    def load(self):
        path = os.path.join(MODEL_DIR,
                            f"{self.ticker}_{self.__class__.__name__}.pkl")
        if not os.path.exists(path):
            raise FileNotFoundError(f"Model not found: {path}")
        self.model = joblib.load(path)


# ─────────────────────────────────────────────────────────────────────
# Ridge Regression
# ─────────────────────────────────────────────────────────────────────

class RidgePredictor(BaseStockPredictor):
    def fit(self, X_train, y_train):
        tscv = TimeSeriesSplit(n_splits=5)
        self.model = RidgeCV(
            alphas=[0.001, 0.01, 0.1, 1.0, 10.0],
            cv=tscv,
        ).fit(X_train, y_train)
        logger.info(f"[{self.ticker}] Ridge best alpha={self.model.alpha_:.4f}")
        return self

    def predict(self, X):
        return self.model.predict(X)


# ─────────────────────────────────────────────────────────────────────
# Decision Tree
# ─────────────────────────────────────────────────────────────────────

class DecisionTreePredictor(BaseStockPredictor):
    def fit(self, X_train, y_train):
        tscv = TimeSeriesSplit(n_splits=5)
        param_grid = {
            "max_depth": [5, 7, 10, 15],
            "min_samples_leaf": [5, 10, 20],
        }
        base = DecisionTreeRegressor(random_state=SEED)
        gs = GridSearchCV(base, param_grid, cv=tscv,
                          scoring="neg_mean_absolute_error", n_jobs=-1)
        gs.fit(X_train, y_train)
        self.model = gs.best_estimator_
        logger.info(f"[{self.ticker}] DT best params={gs.best_params_}")
        return self

    def predict(self, X):
        return self.model.predict(X)


# ─────────────────────────────────────────────────────────────────────
# Random Forest
# ─────────────────────────────────────────────────────────────────────

class RandomForestPredictor(BaseStockPredictor):
    def fit(self, X_train, y_train):
        tscv = TimeSeriesSplit(n_splits=5)
        param_dist = {
            "max_depth": [10, 15, 20],
            "max_features": ["sqrt", "log2", 0.3],
            "n_estimators": [500],
        }
        base = RandomForestRegressor(random_state=SEED, n_jobs=-1)
        rs = RandomizedSearchCV(base, param_dist, n_iter=50,
                                cv=tscv,
                                scoring="neg_mean_absolute_error",
                                n_jobs=-1, random_state=SEED)
        rs.fit(X_train, y_train)
        self.model = rs.best_estimator_
        logger.info(f"[{self.ticker}] RF best params={rs.best_params_}")
        return self

    def predict(self, X):
        return self.model.predict(X)

    def feature_importances(self) -> np.ndarray:
        return self.model.feature_importances_
