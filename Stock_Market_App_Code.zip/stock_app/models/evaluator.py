"""
DirectionalEvaluator — full classification metrics + statistical tests.
  • confusion matrix, precision, recall, F1, MCC
  • Binomial proportion test (directional accuracy vs random)
  • Wilcoxon signed-rank test (pairwise model MAE comparison)
  • Friedman test (overall multi-model comparison)
"""

import numpy as np
from scipy.stats import wilcoxon, friedmanchisquare, binom_test
from sklearn.metrics import (
    confusion_matrix, classification_report,
    matthews_corrcoef, f1_score, precision_score, recall_score
)


class DirectionalEvaluator:
    """Evaluate directional (up/down) prediction performance."""

    def evaluate(self, y_true: np.ndarray,
                 y_pred: np.ndarray) -> dict:
        """
        Returns dict with:
          confusion_matrix, accuracy, precision, recall,
          f1, mcc, binomial_p
        """
        actual_dir = (np.diff(y_true) > 0).astype(int)
        pred_dir   = (np.diff(y_pred) > 0).astype(int)

        cm  = confusion_matrix(actual_dir, pred_dir)
        acc = float((actual_dir == pred_dir).mean())
        pre = float(precision_score(actual_dir, pred_dir, zero_division=0))
        rec = float(recall_score(actual_dir, pred_dir, zero_division=0))
        f1  = float(f1_score(actual_dir, pred_dir, zero_division=0))
        mcc = float(matthews_corrcoef(actual_dir, pred_dir))

        n_correct = int((actual_dir == pred_dir).sum())
        n_total   = len(actual_dir)
        # one-sided: accuracy > 0.5
        binom_p = float(binom_test(n_correct, n_total,
                                   p=0.5, alternative="greater"))

        return {
            "confusion_matrix":      cm.tolist(),
            "directional_accuracy":  round(acc, 4),
            "precision_up":          round(pre, 4),
            "recall_up":             round(rec, 4),
            "f1":                    round(f1, 4),
            "mcc":                   round(mcc, 4),
            "binomial_p":            round(binom_p, 6),
            "n_correct":             n_correct,
            "n_total":               n_total,
        }


class StatisticalValidator:
    """Hypothesis tests for model comparison."""

    @staticmethod
    def wilcoxon_pairwise(mae_a: list, mae_b: list,
                          label_a: str = "A",
                          label_b: str = "B") -> dict:
        """
        One-sided Wilcoxon: H0 mae_a == mae_b, H1 mae_a < mae_b
        (i.e., model A is better).
        """
        diffs = np.array(mae_a) - np.array(mae_b)
        if (diffs == 0).all():
            return {"W": 0, "p_value": 1.0, "reject_h0": False}
        W, p = wilcoxon(diffs, alternative="less")
        return {
            "comparison": f"{label_a} vs {label_b}",
            "W": float(W),
            "p_value": round(float(p), 6),
            "reject_h0": bool(p < 0.05),
            "effect_size": _rank_biserial(diffs),
        }

    @staticmethod
    def friedman_test(*mae_lists: list) -> dict:
        """Non-parametric ANOVA across k models × n stocks."""
        stat, p = friedmanchisquare(*mae_lists)
        return {
            "chi2": round(float(stat), 4),
            "p_value": round(float(p), 6),
            "reject_h0": bool(p < 0.05),
        }


def _rank_biserial(diffs: np.ndarray) -> float:
    """Rank-biserial correlation as effect size for Wilcoxon."""
    n   = len(diffs)
    pos = (diffs < 0).sum()   # A < B (A wins)
    neg = (diffs > 0).sum()
    return round(float((pos - neg) / n), 4)
