"""
Entry point — run Flask dev server.
For production use gunicorn: gunicorn -w 4 "run:app"
"""

from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
