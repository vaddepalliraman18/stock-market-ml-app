"""
shadow_validate.py — 30-day live shadow validation.

Loads pre-trained LSTM models, generates next-day predictions for all
tickers each morning, then records actual close prices to measure
live MAE and directional accuracy.

Usage:
    python shadow_validate.py --start 2024-01-01 --end 2024-02-16
    python shadow_validate.py --report          # summarise saved results
"""

import argparse, json, logging, os
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import yfinance as yf

from pipeline.features import FeatureEngineer
from pipeline.preprocessor import StockPreprocessor
from models.lstm_model import LSTMPredictor
from models.evaluator import DirectionalEvaluator

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

TICKERS   = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "INFY.NS", "ICICIBANK.NS",
    "AAPL", "MSFT", "AMZN", "GOOGL", "TSLA",
]
LOG_FILE  = "shadow_validation_log.json"
LOOKBACK  = 200   # days of history needed to build features


def get_features_for_date(ticker: str, as_of: str) -> tuple:
    """
    Fetch the most recent LOOKBACK trading days ending on `as_of`,
    build features, and return (X, last_close).
    """
    end   = (datetime.strptime(as_of, "%Y-%m-%d") + timedelta(days=1)
             ).strftime("%Y-%m-%d")
    start = (datetime.strptime(as_of, "%Y-%m-%d") - timedelta(days=LOOKBACK * 2)
             ).strftime("%Y-%m-%d")

    raw = yf.download(ticker, start=start, end=end,
                      auto_adjust=True, progress=False)
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = raw.columns.get_level_values(0)
    if raw.empty:
        raise ValueError(f"No data for {ticker} as of {as_of}")

    fe = FeatureEngineer()
    df = fe.transform(raw)
    feature_cols = [c for c in df.columns
                    if c not in {"Open","High","Low","Close","Volume"}]
    X = df[feature_cols].values.astype(np.float32)
    last_close = float(df["Close"].iloc[-1])
    return X, last_close


def run_validation(start: str, end: str):
    log = []

    # Get all trading dates in the window
    all_dates = pd.bdate_range(start=start, end=end).strftime("%Y-%m-%d").tolist()
    logger.info(f"Shadow validation: {len(all_dates)} trading days, "
                f"{len(TICKERS)} tickers")

    for ticker in TICKERS:
        model = LSTMPredictor(ticker)
        try:
            model.load()
        except FileNotFoundError:
            logger.warning(f"[{ticker}] LSTM not found — skipping")
            continue

        predictions, actuals = [], []

        for i, date in enumerate(all_dates[:-1]):   # predict D, check D+1
            next_date = all_dates[i + 1]
            try:
                X, last_close = get_features_for_date(ticker, date)
                pred_mean, _, _ = model.predict_with_ci(X, passes=5)
                predicted = float(pred_mean[-1])

                # Fetch actual next-day close
                actual_df = yf.download(
                    ticker, start=next_date,
                    end=(datetime.strptime(next_date, "%Y-%m-%d")
                         + timedelta(days=3)).strftime("%Y-%m-%d"),
                    auto_adjust=True, progress=False,
                )
                if actual_df.empty:
                    continue
                actual = float(actual_df["Close"].iloc[0])

                predictions.append(predicted)
                actuals.append(actual)

                mae_today = abs(predicted - actual)
                dir_correct = int(
                    (predicted > last_close) == (actual > last_close)
                )
                logger.info(f"[{ticker}] {date}→{next_date}  "
                            f"pred={predicted:.2f} actual={actual:.2f}  "
                            f"mae={mae_today:.2f}  dir={'✓' if dir_correct else '✗'}")
            except Exception as exc:
                logger.error(f"[{ticker}] {date}: {exc}")

        if predictions:
            preds_arr   = np.array(predictions)
            actuals_arr = np.array(actuals)
            live_mae    = float(np.mean(np.abs(preds_arr - actuals_arr)))
            dir_eval    = DirectionalEvaluator()
            dir_result  = dir_eval.evaluate(actuals_arr, preds_arr)

            log.append({
                "ticker":              ticker,
                "n_days":              len(predictions),
                "live_mae":            round(live_mae, 4),
                "live_directional_acc": dir_result["directional_accuracy"],
                "binomial_p":          dir_result["binomial_p"],
            })
            logger.info(f"[{ticker}] SUMMARY  live_mae={live_mae:.4f}  "
                        f"dir_acc={dir_result['directional_accuracy']:.1%}")

    with open(LOG_FILE, "w") as f:
        json.dump({"start": start, "end": end, "results": log}, f, indent=2)
    logger.info(f"Validation log saved → {LOG_FILE}")
    return log


def print_report():
    if not os.path.exists(LOG_FILE):
        print("No validation log found. Run with --start / --end first.")
        return
    with open(LOG_FILE) as f:
        data = json.load(f)

    print(f"\nShadow Validation  {data['start']} → {data['end']}")
    print(f"{'Ticker':<15} {'N days':>6} {'Live MAE':>10} "
          f"{'Dir Acc':>10} {'Binom p':>10}")
    print("-" * 55)
    for r in data["results"]:
        print(f"{r['ticker']:<15} {r['n_days']:>6} {r['live_mae']:>10.4f} "
              f"{r['live_directional_acc']:>10.1%} {r['binomial_p']:>10.6f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start",  default="2024-01-01")
    parser.add_argument("--end",    default="2024-02-16")
    parser.add_argument("--report", action="store_true")
    args = parser.parse_args()

    if args.report:
        print_report()
    else:
        run_validation(args.start, args.end)
        print_report()


if __name__ == "__main__":
    main()
