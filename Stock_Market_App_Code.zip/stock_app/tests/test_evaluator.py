"""
Unit tests for DirectionalEvaluator and StatisticalValidator.
Run: pytest tests/ -v
"""

import pytest
import numpy as np
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from models.evaluator import DirectionalEvaluator, StatisticalValidator


@pytest.fixture
def sample_prices():
    """Synthetic rising price series with noise."""
    np.random.seed(42)
    t = np.arange(100)
    price = 100 + 0.5 * t + np.random.randn(100) * 2
    return price


class TestDirectionalEvaluator:

    def test_perfect_predictions(self):
        y_true = np.array([10, 11, 12, 13, 14, 15])
        y_pred = np.array([10, 11, 12, 13, 14, 15])
        result = DirectionalEvaluator().evaluate(y_true, y_pred)
        assert result["directional_accuracy"] == 1.0
        assert result["precision_up"] == 1.0

    def test_random_predictions(self, sample_prices):
        """Random predictions should give ~50% directional accuracy."""
        np.random.seed(0)
        y_pred = np.random.permutation(sample_prices)
        result = DirectionalEvaluator().evaluate(sample_prices, y_pred)
        assert 0.3 < result["directional_accuracy"] < 0.7

    def test_output_keys(self, sample_prices):
        np.random.seed(1)
        y_pred = sample_prices + np.random.randn(len(sample_prices))
        result = DirectionalEvaluator().evaluate(sample_prices, y_pred)
        expected_keys = {"confusion_matrix", "directional_accuracy",
                         "precision_up", "recall_up", "f1", "mcc", "binomial_p"}
        assert expected_keys.issubset(result.keys())

    def test_mcc_range(self, sample_prices):
        y_pred = sample_prices + 0.1
        result = DirectionalEvaluator().evaluate(sample_prices, y_pred)
        assert -1.0 <= result["mcc"] <= 1.0


class TestStatisticalValidator:

    def test_wilcoxon_reject(self):
        mae_a = [1.0, 1.1, 0.9, 1.0, 1.2, 0.8, 1.1, 0.9, 1.0, 1.0]
        mae_b = [2.0, 2.1, 1.9, 2.0, 2.2, 1.8, 2.1, 1.9, 2.0, 2.0]
        res = StatisticalValidator.wilcoxon_pairwise(mae_a, mae_b, "LSTM", "RF")
        assert res["reject_h0"] is True
        assert res["p_value"] < 0.05

    def test_wilcoxon_not_reject(self):
        mae_a = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
        mae_b = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
        # Identical arrays — Wilcoxon should not reject
        res = StatisticalValidator.wilcoxon_pairwise(mae_a, mae_b)
        assert res["reject_h0"] is False

    def test_friedman(self):
        m1 = [1.0, 1.1, 0.9, 1.0, 1.2, 0.8, 1.1, 0.9, 1.0, 0.95]
        m2 = [2.0, 2.1, 1.9, 2.0, 2.2, 1.8, 2.1, 1.9, 2.0, 1.95]
        m3 = [3.0, 3.1, 2.9, 3.0, 3.2, 2.8, 3.1, 2.9, 3.0, 2.95]
        m4 = [4.0, 4.1, 3.9, 4.0, 4.2, 3.8, 4.1, 3.9, 4.0, 3.95]
        res = StatisticalValidator.friedman_test(m1, m2, m3, m4)
        assert res["reject_h0"] is True
