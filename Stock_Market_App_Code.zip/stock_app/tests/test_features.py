"""Unit tests for FeatureEngineer — verify feature count and no NaN leakage."""

import pytest
import numpy as np
import pandas as pd
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pipeline.features import FeatureEngineer


@pytest.fixture
def sample_ohlcv():
    np.random.seed(42)
    n = 300
    dates = pd.date_range("2020-01-01", periods=n, freq="B")
    close = 100 + np.cumsum(np.random.randn(n) * 0.5)
    df = pd.DataFrame({
        "Open":   close * (1 + np.random.uniform(-0.005, 0.005, n)),
        "High":   close * (1 + np.random.uniform( 0.000, 0.010, n)),
        "Low":    close * (1 - np.random.uniform( 0.000, 0.010, n)),
        "Close":  close,
        "Volume": np.random.randint(100_000, 10_000_000, n).astype(float),
    }, index=dates)
    return df


def test_feature_count(sample_ohlcv):
    fe = FeatureEngineer()
    out = fe.transform(sample_ohlcv)
    extra = [c for c in out.columns
             if c not in {"Open","High","Low","Close","Volume"}]
    # Should produce ~48 features (may vary slightly by ±1 due to naming)
    assert 45 <= len(extra) <= 52, f"Got {len(extra)} features"


def test_no_nan_after_transform(sample_ohlcv):
    fe = FeatureEngineer()
    out = fe.transform(sample_ohlcv)
    assert not out.isnull().any().any(), "NaN values found after transform"


def test_row_count_reduced(sample_ohlcv):
    """dropna removes the warm-up period (SMA-200 needs 200 rows)."""
    fe = FeatureEngineer()
    out = fe.transform(sample_ohlcv)
    assert len(out) < len(sample_ohlcv)
    assert len(out) > 0


def test_rsi_range(sample_ohlcv):
    fe = FeatureEngineer()
    out = fe.transform(sample_ohlcv)
    assert out["rsi_14"].between(0, 100).all()


def test_bb_ordering(sample_ohlcv):
    fe = FeatureEngineer()
    out = fe.transform(sample_ohlcv)
    assert (out["bb_upper"] >= out["bb_mid"]).all()
    assert (out["bb_mid"]   >= out["bb_lower"]).all()
