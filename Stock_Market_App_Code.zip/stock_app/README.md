# Stock Market Analysis and Prediction Application

MCA Final Project — Amity University Online  
**Stack:** Python · Flask · TensorFlow/Keras · scikit-learn · SQLite · Plotly.js · Docker

---

## Project Structure

```
stock_app/
├── pipeline/
│   ├── preprocessor.py      # 5-step preprocessing pipeline
│   ├── features.py          # 48 feature engineering
│   └── data_pipeline.py     # ETL: yfinance → SQLite
├── models/
│   ├── base_model.py        # Ridge, Decision Tree, Random Forest
│   ├── lstm_model.py        # 2-layer LSTM + Monte Carlo Dropout CI
│   ├── evaluator.py         # DirectionalEvaluator + statistical tests
│   └── model_factory.py     # Train/load all 4 models per ticker
├── app/
│   ├── __init__.py          # Flask app factory
│   ├── blueprints/
│   │   ├── main.py          # Page routes (/, /compare, /watchlist, /audit)
│   │   └── api.py           # REST API /api/v1/*
│   └── templates/           # HTML pages
├── tests/
│   ├── test_evaluator.py    # Unit tests for evaluator + stat tests
│   └── test_features.py     # Unit tests for feature engineering
├── train.py                 # Training script
├── shadow_validate.py       # 30-day live validation script
├── run.py                   # Flask dev server entry point
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

---

## Quick Start

### 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### 2 — Train models
```bash
# Train all tickers and all models (takes ~3-4 hours with GPU)
python train.py

# Train a single ticker only
python train.py --ticker TCS.NS

# Train one model for one ticker
python train.py --ticker AAPL --model lstm
```

### 3 — Run the web app
```bash
python run.py
# Open http://localhost:5000
```

### 4 — Docker (production)
```bash
docker-compose up --build
# Open http://localhost:5000
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/tickers` | List all supported tickers |
| POST | `/api/v1/stock-data` | OHLCV + indicator series |
| POST | `/api/v1/predict` | Run prediction with confidence intervals |
| GET  | `/api/v1/model-comparison/<ticker>` | All 4 model metrics |
| GET  | `/api/v1/audit-log` | Session prediction history |

### Example — POST /api/v1/predict
```json
{
  "ticker": "TCS.NS",
  "model": "lstm",
  "horizon": 1
}
```

---

## Run Tests
```bash
pytest tests/ -v
```

---

## Shadow Validation
```bash
# Run 30-day live validation (after training)
python shadow_validate.py --start 2024-01-01 --end 2024-02-16

# View saved report
python shadow_validate.py --report
```

---

## Supported Tickers
| NSE India | Global |
|-----------|--------|
| RELIANCE.NS | AAPL |
| TCS.NS | MSFT |
| HDFCBANK.NS | AMZN |
| INFY.NS | GOOGL |
| ICICIBANK.NS | TSLA |

---

## License
MIT — free to use, modify, and distribute.
